G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.3*
G04 #@! TF.CreationDate,2026-03-18T17:31:10+01:00*
G04 #@! TF.ProjectId,rotary_switch,726f7461-7279-45f7-9377-697463682e6b,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.3) date 2026-03-18 17:31:10*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X-0.550000X-0.750000X0.550000X-0.750000X0.550000X0.750000X-0.550000X0.750000X0*%
%ADD11RoundRect,0.240000X0.560000X0.760000X-0.560000X0.760000X-0.560000X-0.760000X0.560000X-0.760000X0*%
%ADD12R,2.000000X2.000000*%
%ADD13C,2.000000*%
%ADD14R,2.000000X3.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X10730000Y-6500000D03*
X13270000Y-6500000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X-9460000Y-6500000D03*
X-12000000Y-6500000D03*
X-14540000Y-6500000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,SW1*
X-2550000Y-7500000D03*
D13*
X2450000Y-7500000D03*
X-50000Y-7500000D03*
D14*
X-5650000Y0D03*
X5550000Y0D03*
D13*
X2450000Y7000000D03*
X-2550000Y7000000D03*
G04 #@! TD*
M02*
